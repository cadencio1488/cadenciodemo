'use strict';
const $=s=>document.querySelector(s);
const previews={
 received:[['lucas','LM','Lucas Martin','Prise de muscle','−0,4 kg','Gêne signalée','Traiter'],['emma','EL','Emma Laurent','Perte de poids','−0,3 kg','3/4 séances','Traiter']],
 pending:[['thomas','TB','Thomas Bernard','Performance','—','Bilan attendu','Ouvrir'],['hugo','HP','Hugo Petit','Prise de muscle','—','Bilan attendu','Ouvrir']],
 done:[['lea','LM','Léa Moreau','Remise en forme','+0,1 kg','Traité','Voir le suivi']]
};
document.querySelectorAll('[data-preview-filter]').forEach(button=>button.addEventListener('click',()=>{document.querySelectorAll('[data-preview-filter]').forEach(b=>b.setAttribute('aria-pressed',String(b===button)));$('#preview-list').innerHTML=previews[button.dataset.previewFilter].map(([id,initials,name,goal,weight,signal,action],i)=>`<a class="preview-client" href="/demo/#client/${id}"><span class="preview-avatar ${i?'purple':''}">${initials}</span><div><strong>${name}</strong><small>${goal}</small></div><span class="preview-weight">${weight}</span><span class="client-tag ${signal==='Gêne signalée'?'amber':''}">${signal}</span><span class="preview-action">${action}</span></a>`).join('');}));
function calculate(){const n=Number($('#calc-clients').value),before=Number($('#calc-before').value),after=Number($('#calc-after').value);$('#clients-value').textContent=n;const valid=before>=1&&before<=90&&after>=1&&after<=90;const minutes=valid?Math.max(0,n*(before-after)):0;const format=m=>{const value=Math.round(m);return Math.floor(value/60)+' h'+(value%60?' '+String(value%60).padStart(2,'0'):'');};$('#weekly-saving').textContent=valid?format(minutes):'—';$('#monthly-saving').textContent=valid?format(minutes*52/12):'—';$('#per-client-saving').textContent=valid?(before>after?(before-after)+' min de moins':'Objectif à ajuster'):'Vérifiez vos hypothèses';}
['#calc-clients','#calc-before','#calc-after'].forEach(id=>$(id).addEventListener('input',calculate));calculate();
