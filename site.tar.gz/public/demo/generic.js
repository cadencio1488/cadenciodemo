'use strict';
(() => {
  const previous=render;
  const bar=document.createElement('div');bar.className='experience-bar';
  bar.innerHTML='<span class="demo-mode-label"><i></i>DÉMONSTRATION</span><span>40 clients d’exemple · essais sur cet appareil</span><a href="/">Retour au site <svg class="direction-icon" viewBox="0 0 16 16" aria-hidden="true" focusable="false"><path d="M4 12 12 4M4 4h8v8" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></a>';
  document.querySelector('.app-shell').prepend(bar);
  const originalSeed=seed;
  seed=function(){const result=originalSeed();result.clients.forEach(c=>{if(c.portal?.docs){c.portal.docs.training.url='programme-exemple.pdf';c.portal.docs.diet.url='nutrition-exemple.pdf';}});return result;};
  render=function(){previous();document.querySelector('.demo-badge').textContent='DÉMO · DONNÉES FICTIVES';};
  const footer=document.querySelector('footer');
  footer.insertAdjacentHTML('beforeend',' · <button class="text-button" data-export-workspace>Exporter mes essais</button> · <a href="/confidentialite/">Données de la démo</a>');
  document.addEventListener('click',e=>{if(e.target.closest('[data-export-workspace]')){const blob=new Blob([JSON.stringify(state,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='cadencio-demo.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}});
  window.addEventListener('hashchange',()=>render());render();
})();
