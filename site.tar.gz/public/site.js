'use strict';
const $=s=>document.querySelector(s);
const previews={
 received:[['lucas','LM','Lucas Martin','Prise de muscle','−0,4 kg','4/4 séances','Gêne signalée'],['emma','EL','Emma Laurent','Perte de poids','−0,3 kg','3/4 séances','Bilan reçu']],
 pending:[['thomas','TB','Thomas Bernard','Performance','—','Bilan attendu','En attente'],['hugo','HP','Hugo Petit','Prise de muscle','—','Bilan attendu','En attente']],
 done:[['lea','LM','Léa Moreau','Remise en forme','+0,1 kg','3/3 séances','Traité']]
};
document.querySelectorAll('[data-preview-filter]').forEach(button=>button.addEventListener('click',()=>{
 document.querySelectorAll('[data-preview-filter]').forEach(b=>b.setAttribute('aria-pressed',String(b===button)));
 $('#preview-list').innerHTML=previews[button.dataset.previewFilter].map(([id,initials,name,goal,weight,sessions,signal],i)=>'<a class="preview-client" href="/demo/#client/'+id+'"><span class="preview-avatar '+(i?'sand':'')+'">'+initials+'</span><div class="preview-person"><strong>'+name+'</strong><small>'+goal+'</small></div><div class="preview-result"><strong>'+weight+'</strong><small>'+sessions+'</small></div><span class="client-tag '+(signal==='Gêne signalée'?'amber':'')+'">'+signal+'</span><span class="preview-arrow" aria-hidden="true"><svg class="direction-icon" viewBox="0 0 16 16" aria-hidden="true" focusable="false"><path d="M4 12 12 4M4 4h8v8" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></span></a>').join('');
}));
const caseTabs=[...document.querySelectorAll('[data-case]')];
function selectCase(button,focus=false){
 caseTabs.forEach(tab=>{const selected=tab===button;tab.setAttribute('aria-selected',String(selected));tab.tabIndex=selected?0:-1;$('#case-'+tab.dataset.case).hidden=!selected;});
 if(focus)button.focus();
}
caseTabs.forEach((button,index)=>{
 button.addEventListener('click',()=>selectCase(button));
 button.addEventListener('keydown',event=>{
  let next;
  if(event.key==='ArrowRight')next=caseTabs[(index+1)%caseTabs.length];
  if(event.key==='ArrowLeft')next=caseTabs[(index-1+caseTabs.length)%caseTabs.length];
  if(event.key==='Home')next=caseTabs[0];
  if(event.key==='End')next=caseTabs.at(-1);
  if(next){event.preventDefault();selectCase(next,true);}
 });
});
function calculate(){
 const n=Number($('#calc-clients').value),before=Number($('#calc-before').value),after=Number($('#calc-after').value);
 $('#clients-value').textContent=n;
 const valid=before>=1&&before<=90&&after>=1&&after<=90,minutes=valid?Math.max(0,n*(before-after)):0;
 const format=m=>{const value=Math.round(m);return Math.floor(value/60)+' h'+(value%60?' '+String(value%60).padStart(2,'0'):'');};
 $('#weekly-saving').textContent=valid?format(minutes):'—';
 $('#monthly-saving').textContent=valid?format(minutes*52/12):'—';
 $('#per-client-saving').textContent=valid?(before>after?(before-after)+' min de moins':'Objectif à ajuster'):'Vérifiez vos valeurs';
}
['#calc-clients','#calc-before','#calc-after'].forEach(id=>$(id).addEventListener('input',calculate));calculate();
