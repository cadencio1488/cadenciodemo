'use strict';
(() => {
 const previous=render;
 function polish(){
  document.querySelectorAll('.brand-symbol').forEach(el=>{if(!el.querySelector('img'))el.innerHTML='<img src="/assets/cadencio-mark-v21.png" alt="" width="39" height="39">';});
  document.querySelectorAll('.brand-text small').forEach(el=>el.textContent='Suivi clients');
  const note=document.querySelector('.sidebar-note');
  if(note){const n=counts();note.innerHTML='<span class="note-mark">SUIVIS DE LA SEMAINE</span><strong>'+n.done+' / '+n.total+' terminés</strong><div class="sidebar-progress" aria-label="'+n.done+' suivis traités sur '+n.total+'"><i style="width:'+(n.total?n.done/n.total*100:0)+'%"></i></div><p>'+n.todo+' bilans à traiter · '+n.pending+' réponses attendues</p>';}
  const heading=document.querySelector('.composer-heading');
  if(heading){heading.querySelector('h2').textContent='Votre retour';heading.querySelector('p').textContent='Préparez votre message, puis ajoutez votre analyse et les points à discuter.';}
  const action=document.querySelector('[data-prepare-coach-return]');
  if(action)action.innerHTML=icon('message')+' Préparer mon retour';
  const caption=document.querySelector('.simulation-label');
  if(caption)caption.textContent='Proposition à partir du bilan · à relire et adapter';
 }
 render=function(){previous();polish();};
 window.addEventListener('hashchange',polish);
 render();
})();
