import {readFile, readdir, stat} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../public');
const origin = 'https://local.invalid';
let files = 0;
let links = 0;

async function checkReference(reference, file) {
  if (!reference || reference.startsWith('#') || /^(data:|mailto:|tel:|javascript:)/i.test(reference)) return;
  const relative = path.relative(root, file).split(path.sep).join('/');
  const url = new URL(reference, `${origin}/${relative}`);
  if (url.origin !== origin) return;
  let target = path.join(root, decodeURIComponent(url.pathname));
  try {
    if ((await stat(target)).isDirectory()) target = path.join(target, 'index.html');
    if (!(await stat(target)).isFile()) throw new Error('Ce chemin ne correspond pas à un fichier.');
  } catch {
    throw new Error(`Lien local manquant dans ${relative} : ${reference}`);
  }
  links++;
}

async function walk(directory) {
  for (const entry of await readdir(directory, {withFileTypes: true})) {
    const file = path.join(directory, entry.name);
    if (entry.isDirectory()) {
      await walk(file);
      continue;
    }
    files++;
    if (entry.name.endsWith('.js')) {
      const result = spawnSync(process.execPath, ['--check', file], {encoding: 'utf8'});
      if (result.status !== 0) throw new Error(result.stderr || `JavaScript invalide : ${file}`);
    }
    if (!/\.(html|css)$/.test(entry.name)) continue;
    const content = await readFile(file, 'utf8');
    const expression = entry.name.endsWith('.html')
      ? /(?:src|href)=["']([^"']+)["']/g
      : /url\(\s*["']?([^"')]+)["']?\s*\)/g;
    for (const match of content.matchAll(expression)) await checkReference(match[1].trim(), file);
  }
}

await walk(root);
console.log(`Site prêt : ${files} fichiers et ${links} liens locaux vérifiés.`);
