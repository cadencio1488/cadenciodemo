'use strict';
(() => {
  const previous=render;
  render=function(){previous();let guide=document.querySelector('#demo-loop-guide');if(!guide){guide=document.createElement('div');guide.id='demo-loop-guide';guide.className='demo-loop-guide';document.querySelector('.experience-bar').after(guide);}guide.innerHTML='<span>Essayez la boucle complète</span><a href="#portal/thomas/checkin">1 · Remplir le bilan</a><a href="#client/thomas">2 · Préparer le retour</a><a href="#portal/thomas/home">3 · Voir le retour client</a>';};
  window.addEventListener('hashchange',()=>render());render();
})();
