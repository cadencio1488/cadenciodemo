'use strict';
(() => {
  const previous=render;
  render=function(){previous();let guide=document.querySelector('#demo-loop-guide');if(!guide){guide=document.createElement('div');guide.id='demo-loop-guide';guide.className='demo-loop-guide';document.querySelector('.experience-bar').after(guide);}guide.innerHTML='<span>Parcours avec Thomas</span><a href="#portal/thomas/checkin">1 · Bilan client</a><a href="#client/thomas">2 · Retour coach</a><a href="#portal/thomas/home">3 · Côté client</a>';};
  window.addEventListener('hashchange',()=>render());render();
})();
