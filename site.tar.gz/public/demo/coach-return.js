'use strict';
(() => {
  const weight=r=>r&&typeof r.weight==='number'&&Number.isFinite(r.weight)&&r.weight>0;
  function prepare(c,r){
    const previous=previousRecord(c,r),name=c.name.trim().split(/\s+/)[0];
    const lines=['Salut '+name+',','Merci pour ton bilan.',''];
    if(weight(r))lines.push('Ton poids est de '+fmt(r.weight)+' kg'+(weight(previous)?', soit '+signed(r.weight-previous.weight,true)+' kg par rapport au bilan précédent.':'.'));
    lines.push('Tu as réalisé '+r.completed+' séance'+(r.completed>1?'s':'')+' sur '+r.planned+' prévue'+(r.planned>1?'s':'')+'.');
    lines.push('Tu évalues ton sommeil à '+r.sleep+'/5'+(previous&&r.sleep<previous.sleep?', en baisse par rapport au bilan précédent ('+previous.sleep+'/5).':previous&&r.sleep>previous.sleep?', en hausse par rapport au bilan précédent ('+previous.sleep+'/5).':'.'));
    if(r.fatigue>=4||r.hunger>=4)lines.push('Tu notes '+[r.fatigue>=4?'une fatigue à '+r.fatigue+'/5':'',r.hunger>=4?'une faim à '+r.hunger+'/5':''].filter(Boolean).join(' et ')+'.');
    if(r.pain?.trim())lines.push('Tu as aussi signalé une gêne. J’aimerais préciser ce point avec toi.');
    const questions=[];
    if(r.completed<r.planned)questions.push('Qu’est-ce qui t’a empêché de réaliser les séances prévues ?');
    if(r.sleep<=2||(previous&&r.sleep<previous.sleep))questions.push('Qu’est-ce qui a compliqué ton sommeil cette semaine ?');
    if(r.pain?.trim())questions.push('Pour la gêne, peux-tu préciser depuis quand elle est présente et dans quels mouvements tu la ressens ?');
    if(!questions.length)questions.push('Y a-t-il un point que tu souhaites qu’on aborde ensemble ?');
    lines.push('','Pour notre prochain échange :',...questions.map(q=>'• '+q),'','On fait le point ensemble.');
    return lines.join('\n');
  }
  window.CADENCIO_PREPARE_RETURN=prepare;
  const originalComposer=composer;
  composer=function(c,r){return originalComposer(c,r)
    .replace('data-insert-summary','data-prepare-coach-return')
    .replace('Insérer la synthèse factuelle','Préparer mon retour')
    .replace('Synthèse simulée · aucun appel IA','Proposition de message du coach · à relire et adapter')
    .replace('Commencez avec la synthèse, puis ajoutez votre analyse et les points à discuter…','Préparez un message, puis ajoutez votre analyse et les points à discuter…');};
  const dialog=document.createElement('dialog');dialog.id='coach-return-dialog';dialog.setAttribute('aria-labelledby','coach-return-title');
  dialog.innerHTML='<div class="dialog-heading"><h2 id="coach-return-title">Un retour est déjà rédigé.</h2><button class="icon-button" data-close aria-label="Fermer">×</button></div><p>Choisissez comment utiliser la nouvelle proposition. Votre texte reste intact si vous annulez.</p><label for="coach-return-preview">Proposition du coach au client</label><textarea id="coach-return-preview" readonly rows="10"></textarea><p class="field-hint">À relire et adapter avant de copier ou publier.</p><div class="dialog-actions"><button class="button secondary" data-close>Annuler</button><button class="button secondary" data-append-coach-return>Ajouter à mon brouillon</button><button class="button primary" data-replace-coach-return>Remplacer mon brouillon</button></div>';
  document.body.append(dialog);
  const style=document.createElement('style');style.textContent='#coach-return-dialog{width:650px}#coach-return-dialog .dialog-actions{flex-wrap:wrap}#coach-return-preview{width:100%;font-size:1rem;line-height:1.65;resize:vertical}';document.head.append(style);
  let pending=null;
  function insert(append=false){
    if(!pending)return;
    const c=state.clients.find(c=>c.id===pending.clientId),r=c?.records.find(r=>r.id===pending.recordId);
    if(!r||currentClient?.id!==c.id||displayedRecord()?.id!==r.id){dialog.close();pending=null;toast('Rouvrez ce bilan pour préparer le retour.');return;}
    const input=document.querySelector('#return-text'),existing=input.value.trim();
    const next=append&&existing?existing+'\n\n'+pending.text:pending.text;
    if(next.length>8000){toast('Le brouillon est trop long. Raccourcissez-le avant d’ajouter le message.');return;}
    input.value=next;syncReturnInput();dialog.close();pending=null;
    document.querySelector('#return-save-state').textContent=storageAvailable?'Proposition enregistrée · à relire et adapter':'Proposition conservée pour cette session';
    input.focus();toast('Proposition de retour préparée. Relisez-la avant de la partager.');
  }
  document.addEventListener('click',e=>{
    if(e.target.closest('[data-prepare-coach-return]')){
      const c=currentClient,r=displayedRecord();if(!c||!r)return;
      const input=document.querySelector('#return-text'),text=prepare(c,r);
      if(input.value.includes(text)){toast('Cette proposition figure déjà dans votre brouillon.');return;}
      pending={clientId:c.id,recordId:r.id,text};
      if(input.value.trim()){document.querySelector('#coach-return-preview').value=text;dialog.showModal();}else insert();
    }
    if(e.target.closest('[data-append-coach-return]'))insert(true);
    if(e.target.closest('[data-replace-coach-return]'))insert();
  });
  dialog.addEventListener('close',()=>{pending=null;});
  render();
})();
